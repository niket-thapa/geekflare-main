<?php
/**
 * Product List Block Template
 */
?>
<div id="products" class="flex flex-col gap-7.5 pb-8 md:pb-12 lg:pb-20">
    <?php echo $content; ?>
</div>
/**
 * Info Box Block Frontend JavaScript
 *
 * @package Main
 * @since 1.0.0
 */

// No JavaScript needed for info-box block - all functionality handled server-side

